// ============================================
// Japan Lottery Pro — Service Worker
// Versão: 1.0.0
// ============================================

const CACHE_NAME = 'jlp-v1';
const STATIC_CACHE = 'jlp-static-v1';
const API_CACHE = 'jlp-api-v1';

// Arquivos para cache offline
const STATIC_FILES = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  'https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Noto+Sans+JP:wght@300;400;700&display=swap'
];

// ── INSTALL ──────────────────────────────────
self.addEventListener('install', event => {
  console.log('[SW] Instalando Japan Lottery Pro...');
  event.waitUntil(
    caches.open(STATIC_CACHE).then(cache => {
      console.log('[SW] Cacheando arquivos estáticos');
      return cache.addAll(STATIC_FILES.map(url => {
        return new Request(url, { mode: 'no-cors' });
      })).catch(err => {
        console.warn('[SW] Alguns arquivos não foram cacheados:', err);
      });
    })
  );
  self.skipWaiting();
});

// ── ACTIVATE ─────────────────────────────────
self.addEventListener('activate', event => {
  console.log('[SW] Ativando nova versão...');
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames
          .filter(name => name !== STATIC_CACHE && name !== API_CACHE)
          .map(name => {
            console.log('[SW] Removendo cache antigo:', name);
            return caches.delete(name);
          })
      );
    })
  );
  self.clients.claim();
});

// ── FETCH ─────────────────────────────────────
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // Não intercepta chamadas para API da Anthropic
  if (url.hostname === 'api.anthropic.com') {
    return fetch(event.request);
  }

  // Não intercepta extensões de browser
  if (url.protocol === 'chrome-extension:') return;

  // Estratégia: Cache First para estáticos, Network First para o resto
  if (isStaticAsset(url)) {
    event.respondWith(cacheFirst(event.request));
  } else {
    event.respondWith(networkFirst(event.request));
  }
});

function isStaticAsset(url) {
  return url.hostname === 'fonts.googleapis.com' ||
         url.hostname === 'fonts.gstatic.com' ||
         url.pathname.includes('/icons/') ||
         url.pathname.endsWith('.png') ||
         url.pathname.endsWith('.jpg') ||
         url.pathname.endsWith('.svg') ||
         url.pathname.endsWith('.css');
}

// Cache First — serve do cache, busca na rede se não tiver
async function cacheFirst(request) {
  const cached = await caches.match(request);
  if (cached) return cached;
  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(STATIC_CACHE);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    return new Response('Offline', { status: 503 });
  }
}

// Network First — busca na rede, usa cache se offline
async function networkFirst(request) {
  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(STATIC_CACHE);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    const cached = await caches.match(request);
    if (cached) return cached;
    // Fallback para index.html (SPA)
    const fallback = await caches.match('/index.html');
    return fallback || new Response('Offline — Abra o app quando tiver conexão', {
      status: 503,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' }
    });
  }
}

// ── PUSH NOTIFICATIONS ───────────────────────
self.addEventListener('push', event => {
  if (!event.data) return;
  const data = event.data.json();
  const options = {
    body: data.body || 'Novo resultado disponível!',
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-96.png',
    vibrate: [200, 100, 200],
    data: { url: data.url || '/' },
    actions: [
      { action: 'open', title: '🎯 Ver resultado' },
      { action: 'close', title: 'Fechar' }
    ]
  };
  event.waitUntil(
    self.registration.showNotification(
      data.title || '🎰 Japan Lottery Pro',
      options
    )
  );
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  if (event.action === 'open' || !event.action) {
    event.waitUntil(
      clients.openWindow(event.notification.data?.url || '/')
    );
  }
});

// ── BACKGROUND SYNC ──────────────────────────
self.addEventListener('sync', event => {
  if (event.tag === 'sync-results') {
    event.waitUntil(syncLotteryResults());
  }
});

async function syncLotteryResults() {
  console.log('[SW] Sincronizando resultados...');
  // Aqui você pode chamar uma API própria para buscar resultados novos
}

console.log('[SW] Japan Lottery Pro Service Worker carregado ✓');
