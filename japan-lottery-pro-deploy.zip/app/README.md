# 🎰 Japan Lottery Pro — Guia de Publicação e Monetização

## 📁 Estrutura do Projeto

```
japan-lottery-pro/
├── index.html          ← App principal
├── manifest.json       ← Configuração PWA
├── sw.js               ← Service Worker (offline)
├── netlify.toml        ← Config do Netlify
├── icons/
│   ├── icon.svg        ← Ícone fonte (gere os PNGs a partir dele)
│   ├── icon-72.png
│   ├── icon-96.png
│   ├── icon-128.png
│   ├── icon-144.png
│   ├── icon-152.png
│   ├── icon-192.png    ← Obrigatório para PWA
│   ├── icon-384.png
│   └── icon-512.png    ← Obrigatório para PWA
└── README.md
```

---

## 🚀 PASSO 1 — Gerar ícones PNG

Use o site **https://realfavicongenerator.net** ou **https://maskable.app**:

1. Faça upload do `icons/icon.svg`
2. Baixe o pacote com todos os tamanhos
3. Coloque os PNGs na pasta `icons/`

Ou use o comando (requer ImageMagick):
```bash
for size in 72 96 128 144 152 192 384 512; do
  convert icons/icon.svg -resize ${size}x${size} icons/icon-${size}.png
done
```

---

## 🌐 PASSO 2 — Publicar no Netlify (GRÁTIS)

### Opção A — Arrastar e soltar (mais fácil)
1. Acesse **https://netlify.com** e crie conta grátis
2. Na dashboard, arraste a pasta `japan-lottery-pro/` para a área de drop
3. Pronto! URL gerada automaticamente: `seu-app.netlify.app`

### Opção B — Deploy automático via GitHub
```bash
# 1. Crie repositório no GitHub
git init
git add .
git commit -m "Japan Lottery Pro v1.0"
git remote add origin https://github.com/SEU_USER/japan-lottery-pro
git push -u origin main

# 2. No Netlify: New site → Import from GitHub → selecione o repo
```

### Configurar domínio próprio (opcional)
- Compre um domínio: `japanlotterypro.com` (~R$50/ano no Namecheap)
- No Netlify: Site settings → Domain management → Add custom domain

---

## 💰 PASSO 3 — Google AdSense

### Cadastro
1. Acesse **https://adsense.google.com**
2. Clique em "Começar"
3. Insira a URL do seu site Netlify
4. Adicione o código de verificação no `<head>` do `index.html`
5. Aguarde aprovação: **1–14 dias**

### Após aprovação
1. Descomente o script do AdSense no `index.html`:
```html
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX"></script>
```

2. Crie slots de anúncio no painel do AdSense:
   - **Banner nativo**: 320x50 (mobile)
   - **Intersticial**: para abrir ao trocar de loteria

3. Substitua os placeholders no código pelos slots reais:
```html
data-ad-client="ca-pub-SEU_ID"
data-ad-slot="SEU_SLOT_ID"
```

### Estimativa de receita
| Usuários/mês | Receita AdSense |
|--------------|-----------------|
| 1.000        | ~R$ 30–80       |
| 10.000       | ~R$ 300–800     |
| 50.000       | ~R$ 1.500–4.000 |
| 100.000      | ~R$ 3.000–8.000 |

---

## 💳 PASSO 4 — Stripe (Plano PRO)

### Configuração
1. Acesse **https://stripe.com** e crie conta
2. Ative pagamentos em JPY e BRL
3. Crie um produto:
   - **Nome**: Japan Lottery Pro
   - **Preço**: ¥600/mês (JPY) ou R$20/mês (BRL)
   - **Tipo**: Recorrente (assinatura)
4. Gere um Payment Link
5. Substitua no `index.html`:
```javascript
const STRIPE_URL = 'https://buy.stripe.com/SEU_LINK_AQUI';
```

### Webhook (confirmar pagamento automaticamente)
```
Stripe → Developers → Webhooks → Add endpoint
URL: https://seu-backend.com/stripe-webhook
Eventos: customer.subscription.created, customer.subscription.deleted
```

**Sugestão**: Use **Netlify Functions** para o webhook (grátis):
```
netlify/functions/stripe-webhook.js
```

---

## 📱 PASSO 5 — Google Play Store

### Via PWABuilder (mais fácil — sem código)
1. Acesse **https://pwabuilder.com**
2. Cole a URL do Netlify
3. Clique **"Package for Stores"** → **Android**
4. Baixe o `.aab` gerado

### Publicar no Play Store
1. Crie conta: **https://play.google.com/console** → taxa **$25 única**
2. Criar app → Preencher informações:
   - **Título**: Japan Lottery Pro — IA Takarakuji
   - **Categoria**: Entretenimento
   - **Classificação**: +18 (contém jogos de azar)
3. Faça upload do `.aab`
4. Aguarde revisão: **1–3 dias**

### Google AdMob (anúncios no app Android)
1. Crie conta: **https://admob.google.com**
2. Adicione seu app
3. Crie unidades de anúncio:
   - **Banner**: exibido na tela principal
   - **Intersticial**: entre troca de loterias
   - **Recompensado**: "Assista um vídeo para ganhar 3 gerações extras"
4. Substitua os placeholders no código pelos IDs do AdMob

---

## 🍎 PASSO 6 — App Store (iPhone)

### Pré-requisitos
- **Apple Developer Account**: $99/ano em https://developer.apple.com
- **Mac** (ou MacStadium ~$20/mês para alugar online)
- **Xcode** instalado

### Processo
```bash
# Instalar Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/ios
npx cap init "Japan Lottery Pro" "com.japanlotterypro.app"
npx cap add ios

# Build e abrir no Xcode
npx cap copy ios
npx cap open ios
```

No Xcode:
1. Configure Bundle ID: `com.japanlotterypro.app`
2. Assine com seu certificado Apple
3. Archive → Distribute App → App Store Connect

---

## 📊 PASSO 7 — Analytics e Otimização

### Google Analytics 4
Substitua no `index.html`:
```javascript
gtag('config', 'G-SEU_MEASUREMENT_ID');
```

### Eventos já rastreados no app:
- `pwa_install` — usuário instalou o PWA
- `pro_checkout_click` — clicou em assinar PRO
- `pro_purchased` — comprou o PRO

### KPIs para monitorar:
- **DAU/MAU** (usuários diários/mensais)
- **Taxa de conversão PRO** (meta: 2–5%)
- **RPM AdSense** (receita por mil impressões)
- **Retenção D1/D7/D30**

---

## 🎯 Checklist de Lançamento

- [ ] Gerar ícones PNG em todos os tamanhos
- [ ] Publicar no Netlify
- [ ] Cadastrar no Google AdSense
- [ ] Configurar Google Analytics
- [ ] Configurar Stripe
- [ ] Publicar no Google Play
- [ ] Criar página no Instagram/TikTok para divulgar
- [ ] Postar em grupos de brasileiros no Japão (Facebook, WhatsApp)
- [ ] Cadastrar no App Store (opcional)

---

## 📣 Dicas de Divulgação

**Grupos alvos:**
- Grupos de brasileiros no Japão (Facebook)
- Comunidades de dekasseguis
- Fóruns de expatriados brasileiros

**Mensagem sugerida:**
> "Criei um app gratuito para brasileiros que jogam loteria no Japão! Análise por IA, guia de compra em português, frases úteis em japonês e muito mais. Baixe grátis 🇧🇷🇯🇵"

---

## 🆘 Suporte

Dúvidas sobre publicação ou monetização?
Acesse: **https://claude.ai** e pergunte para o Claude!
